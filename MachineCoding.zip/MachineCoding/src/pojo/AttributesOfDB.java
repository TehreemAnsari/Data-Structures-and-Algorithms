package pojo;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AttributesOfDB {
    Map<String, AttributeTypes> attributeTypesMap = new ConcurrentHashMap<>();

    public Map<String, AttributeTypes> getAttributeTypesMap() {
        return attributeTypesMap;
    }

    public void setAttributeTypesMap(Map<String, AttributeTypes> attributeTypesMap) {
        this.attributeTypesMap = attributeTypesMap;
    }
}

package pojo;

public enum AttributeTypes {
    BOOLEAN,
    INT,
    DOUBLE,
    STRING
}

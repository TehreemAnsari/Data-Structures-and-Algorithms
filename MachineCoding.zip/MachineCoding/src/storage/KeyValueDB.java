package storage;

import pojo.AttributeTypes;
import pojo.AttributesOfDB;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class KeyValueDB {
     Map<String, Map<String, String>> keyValueMap;
     AttributesOfDB attributesOfDB;

    public boolean store(String key, Map<String, String> attributeValues) {
        if(key == null || key == "") {
            System.out.println("Not keeping null in keys");
            //throw new IllegalStateException("Not keeping null in keys"); commenting since don't want code flow to break
        }
        Map<String, String> valuesMap = new ConcurrentHashMap<>();
        for (Map.Entry<String, String> entry : attributeValues.entrySet()) {
            System.out.println(entry.getKey() + ":" + entry.getValue());
            String attribute = entry.getKey();
            String value = entry.getValue();

            Map<String, AttributeTypes> attributeTypesMap = attributesOfDB.getAttributeTypesMap();
            if(attributeTypesMap.containsKey(attribute)) {
                AttributeTypes type = attributeTypesMap.get(attribute);
                try {
                    if(type == AttributeTypes.BOOLEAN) {
                        Boolean.parseBoolean(value);
                    } else if(type == AttributeTypes.INT) {
                        Integer.parseInt(value);
                    } else if(type == AttributeTypes.DOUBLE) {
                        Double.parseDouble(value);
                    }
                } catch (Exception e) {
                    System.out.println("Input not compatable with existing type");
                    return false;
                }

            } else {
                if(value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false") ) {
                    attributeTypesMap.put(attribute, AttributeTypes.BOOLEAN);
                } else if(isIntParsable(value)) {
                    attributeTypesMap.put(attribute, AttributeTypes.INT);
                } else if(isDoubleParsable(value)) {
                    attributeTypesMap.put(attribute, AttributeTypes.DOUBLE);
                } else attributeTypesMap.put(attribute, AttributeTypes.STRING);
                attributesOfDB.setAttributeTypesMap(attributeTypesMap);
            }
            valuesMap.put(attribute, value);
        }
        keyValueMap.put(key, valuesMap);
        System.out.println(keyValueMap);
        return true;
    }

    public String fetch(String key) {
        StringBuilder res = new StringBuilder();
        if(!keyValueMap.containsKey(key)) {
            //Throw exception!!!
            System.out.println("No key found");
        } else {
            Map<String, String> tempMap = keyValueMap.get(key);
            for (Map.Entry<String, String> entry : tempMap.entrySet()) {
                res.append(entry.getKey()).append(":").append(entry.getValue()).append("\n");
            }
        }
        return new String(res);
    }

    public boolean delete(String key) {
        if(!keyValueMap.containsKey(key)) {
            //Throw exception if a key being deleted is not available
            return false;
        }
        keyValueMap.remove(key);
        return true;
    }

    public KeyValueDB() {
        keyValueMap = new ConcurrentHashMap<>();
        attributesOfDB = new AttributesOfDB();
    }

    public Map<String, Map<String, String>> getKeyValueMap() {
        return keyValueMap;
    }

    public void setKeyValueMap(Map<String, Map<String, String>> keyValueMap) {
        this.keyValueMap = keyValueMap;
    }

    public AttributesOfDB getAttributesOfDB() {
        return attributesOfDB;
    }

    public void setAttributesOfDB(AttributesOfDB attributesOfDB) {
        this.attributesOfDB = attributesOfDB;
    }

    @Override
    public String toString() {
        return "KeyValueDB{" +
                "keyValueMap=" + keyValueMap +
                ", attributesOfDB=" + attributesOfDB +
                '}';
    }

    private boolean isIntParsable(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (final NumberFormatException e) {
            return false;
        }
    }

    private boolean isDoubleParsable(String input) {
        try {
            Double.parseDouble(input);
            return true;
        } catch (final NumberFormatException e) {
            return false;
        }
    }
}

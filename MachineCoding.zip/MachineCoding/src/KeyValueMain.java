import storage.KeyValueDB;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class KeyValueMain {

    public static void main(String ars[]) {
        KeyValueDB keyValueDB = new KeyValueDB();

        //1. Store Delhi
        Map<String, String> delhi = new ConcurrentHashMap<>();
        delhi.put("pollution_level", "very high");
        delhi.put("population", "10 million");
        delhi.put("lattitude", "1034"); //--> INT
        keyValueDB.store("delhi", delhi);

        // 2. Fetch Delhi
        String resFetch = keyValueDB.fetch("delhi");
        System.out.println("Delhi-->" +resFetch);

        // 3. Store Bangalore
        Map<String, String> blr = new ConcurrentHashMap<>();
        blr.put("lattitude", "33344"); //--> INT
        blr.put("longitude", "9999");
        keyValueDB.store("blr", blr);

        //4. Delete Delhi
        keyValueDB.delete("delhi");

        // 5. Store Jakarta with incorrect attribute type (lattitude as String)
        Map<String, String> jakarta = new ConcurrentHashMap<>();
        jakarta.put("lattitude", "throw error");
        keyValueDB.store("jakarta", jakarta); //--> Prints "Input not compatable with existing type"
        // since lattitude is assigned INT

        // 6. Print Blr and Delhi, blr values printed, delhi gives "No key found" since we deleted delhi in step 4.
        System.out.println("Blr-->"+ keyValueDB.fetch("blr"));
        System.out.println("Delhi-->"+ keyValueDB.fetch("delhi"));

        // 7. Not storing NULL as keys, prints "Not keeping null in keys"
        Map<String, String> india = new ConcurrentHashMap<>();
        india.put("capital", "delhi");
        keyValueDB.store("", india);
    }
}
